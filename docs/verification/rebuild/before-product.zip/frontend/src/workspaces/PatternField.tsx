import { useState } from 'react'
import { api, type JsonRecord } from '../api'
import type { PlanningSession, SimulationRequest, SimulationResult } from '../planning'
import { Badge, Card, Empty, Notice, NumberField, number, obj, list, str, Status, Download } from '../ui'
import { sourceName, methodName } from '../planning'

type Point = {temperature_C:number;temperature_kind:string;latitude:number;longitude:number;depth_m:number;timestamp_utc:string}
type Snapshot = {savedAt:string;signature:string;scenario:SimulationRequest;point:Point;modelUrl:string;before:SimulationResult}
const storageKey='pwn-pre-tase-snapshot-v1'
function savedSnapshot():Snapshot|null {try{const s=JSON.parse(sessionStorage.getItem(storageKey)||'null');return s?.before?.run_id&&s?.scenario?.mode==='north'&&s?.point?s:null}catch{return null}}

export default function PatternField({session,onNorth}:{session:PlanningSession|null;onNorth:()=>void}){
  const [snapshot,setSnapshot]=useState<Snapshot|null>(savedSnapshot)
  const [expected,setExpected]=useState(()=>savedSnapshot()?.point.temperature_C??10),[observed,setObserved]=useState(5),[mismatch,setMismatch]=useState(false),[result,setResult]=useState<JsonRecord|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState(''),[signature,setSignature]=useState('')
  const [latitude,setLatitude]=useState(()=>savedSnapshot()?.point.latitude??78.22),[longitude,setLongitude]=useState(()=>savedSnapshot()?.point.longitude??15.65),[depth,setDepth]=useState(()=>savedSnapshot()?.point.depth_m??5),[timestamp,setTimestamp]=useState(()=>savedSnapshot()?.point.timestamp_utc??'2026-09-22T12:00:00Z')
  const [kind,setKind]=useState('SIMULATION_EXPLANATORY'),[datasetId,setDatasetId]=useState(''),[sampleIndex,setSampleIndex]=useState(0),[modelUrl,setModelUrl]=useState(()=>savedSnapshot()?.modelUrl??'')
  if(!session||session.scenario.mode!=='north')return <Card title="Saha gözleminden aynı üretim motoruna"><Notice>Önce gelecek kuzey modunda bir aday portföy ve kaynak senaryosu seçin. Buradaki karşılaştırma aynı ürünleri, hedefleri ve kısıtları yeniden çalıştırır.</Notice><button className="button primary" onClick={onNorth}>Kuzey simülasyonunu aç</button></Card>
  const point:Point={temperature_C:expected,temperature_kind:'in_situ',latitude,longitude,depth_m:depth,timestamp_utc:timestamp}
  const baselineSignature=JSON.stringify([session.scenario,point,modelUrl])
  const dirty=!!snapshot&&snapshot.signature!==baselineSignature
  const currentSignature=JSON.stringify([snapshot?.before.run_id,observed,mismatch,kind,datasetId,sampleIndex])
  async function save(){setBusy(true);setError('');try{
    const scenario=structuredClone({...session!.scenario,seawater_temperature_c:expected})
    const before=await api.simulate(scenario)
    const next={savedAt:new Date().toISOString(),signature:baselineSignature,scenario,point:structuredClone(point),modelUrl,before}
    setSnapshot(next);setResult(null);try{sessionStorage.setItem(storageKey,JSON.stringify(next))}catch{/* Download remains available if browser storage is unavailable. */}
  }catch(e){setError(e instanceof Error?e.message:'Saha öncesi desen kaydedilemedi')}finally{setBusy(false)}}
  async function run(){if(!snapshot||dirty)return;setBusy(true);setError('');setResult(null);try{
    const next=await api.patternFieldUpdate({simulation:snapshot.scenario,observation:{expected:snapshot.point,observed:{...snapshot.point,temperature_C:observed,timestamp_utc:mismatch?new Date(new Date(snapshot.point.timestamp_utc).getTime()+86400000).toISOString():snapshot.point.timestamp_utc},evidence_kind:kind,...(kind==='EXTERNAL_OBSERVATION'?{observed_dataset_id:datasetId,observed_sample_index:sampleIndex,model_source_url:snapshot.modelUrl}:{})}})
    if((next.before as SimulationResult)?.run_id!==snapshot.before.run_id)throw new Error('Kaydedilen PRE-TASE hesabı yeniden üretilemedi. Veri veya motor sürümü değişmiş olabilir; yeni bir PRE-TASE kaydı oluşturun.')
    setResult(next);setSignature(currentSignature)
  }catch(e){setError(e instanceof Error?e.message:'Yeniden hesaplama tamamlanamadı')}finally{setBusy(false)}}
  const before=snapshot?.before,after=result?.after as SimulationResult|undefined,comparison=obj(result?.comparison),collocation=obj(comparison.collocation)
  return <><div className="workspace-heading"><div><h1>PRE-TASE → gözlem sonrası üretim deseni</h1><p>Önce deseni kaydet. Geçerli gözlemle yalnız desteklenen girdiyi değiştir. Aynı optimizasyon motorunu yeniden çalıştır.</p></div><Badge kind={kind}/></div>
    <Notice>MODEL / VARSAYIM → PWN + fiziksel numune → desteklenen girdi → AYNI KARAR MOTORU → güncellenmiş desen. Şu an çalışan bağlantı yalnız deniz suyu sıcaklığı → arıtma enerji senaryosudur. Tuzluluk ve numune kimyası bağlantıları planlanmıştır.</Notice>
    <div className="two-columns"><Card title="1 · Saha öncesi deseni kaydet">
      <NumberField name="Model suyu sıcaklığı" value={expected} set={setExpected} min={-2} max={45} step={.5} unit="°C"/>
      <p className="small muted">Bu sayı otomatik yüklenmiş bir okyanus profili değildir: kaynak suyu sıcaklığı varsayımıdır. Gerçek model profiliyle değiştirilecek girdidir; yıllık tatlı su miktarını temsil etmez.</p>
      <details><summary>Model eşleştirme noktası / UTC / kaynak</summary><div className="field-grid"><NumberField name="Model enlemi" value={latitude} set={setLatitude} min={-90} max={90} step={.01} unit="°"/><NumberField name="Model boylamı" value={longitude} set={setLongitude} min={-180} max={180} step={.01} unit="°"/></div><NumberField name="Model derinliği" value={depth} set={setDepth} min={0} step={.1} unit="m"/><label className="field"><span>Model UTC zamanı (ISO8601)</span><input aria-label="Model UTC zamanı" value={timestamp} onChange={e=>setTimestamp(e.target.value)}/></label><label className="field"><span>Model kaynağı bağlantısı</span><input aria-label="Model kaynağı bağlantısı" type="url" value={modelUrl} onChange={e=>setModelUrl(e.target.value)}/></label></details>
      <button className="button primary full" disabled={busy} onClick={()=>void save()}>{busy?'Hesaplanıyor…':snapshot?'PRE-TASE desenini yeniden kaydet':'PRE-TASE desenini kaydet'}</button>
      {snapshot&&<><p className="small muted">Kayıt: {new Date(snapshot.savedAt).toLocaleString('tr-TR')} · çalışma kimliği: <span style={{overflowWrap:'anywhere'}}>{snapshot.before.run_id}</span></p><Status value={snapshot.before.status}/><Download data={snapshot} filename="pre-tase-pattern.json"/></>}
      {dirty&&<Notice warn>Senaryo veya model noktası değişti. Kaydedilen PRE-TASE deseni korunuyor; yeni koşullarla karşılaştırmak için yeniden kaydedin.</Notice>}
    </Card><Card title="2 · Gözlemi eşleştir ve aynı motoru çalıştır">
      <label className="field"><span>Kanıt türü</span><select value={kind} onChange={e=>setKind(e.target.value)}><option value="SIMULATION_EXPLANATORY">Açık simülasyon deneyi</option><option value="EXTERNAL_OBSERVATION">Kayıtlı dış gözlem</option></select></label>
      {kind==='SIMULATION_EXPLANATORY'?<><NumberField name="Gözlem senaryosu sıcaklığı" value={observed} set={setObserved} min={-2} max={45} step={.5} unit="°C"/><p className="small muted">AÇIKLAYICI / VARSAYIMA DAYALI SİMÜLASYON. Fiziksel PWN veya TASE ölçümü değildir.</p><label className="check-label"><input type="checkbox" checked={mismatch} onChange={e=>setMismatch(e.target.checked)}/>Zamanı 24 saat kaydır; geçersiz eşleştirmeyi sına</label></>:<><label className="field"><span>Kayıtlı gözlem dataset_id</span><input aria-label="Gözlem veri kimliği" value={datasetId} onChange={e=>setDatasetId(e.target.value)}/></label><NumberField name="Gözlem satırı sample_index" value={sampleIndex} set={setSampleIndex} unit="indeks"/><Notice>Gözlem sıcaklığı ve metaveri kayıtlı kaynaktan alınır. Model kaynak bağlantısını ve eşleştirme noktasını saha öncesi kayda ekleyin. Tank, kalibrasyonsuz veya eşleşmeyen kayıtlar engellenir.</Notice></>}
      <button className="button primary full" disabled={busy||!snapshot||dirty||(kind==='EXTERNAL_OBSERVATION'&&(!datasetId||!snapshot.modelUrl))} onClick={()=>void run()}>{busy?'Aynı motor yeniden çalışıyor…':'Eşleştir ve deseni yeniden hesapla'}</button>
      {!snapshot&&<p className="small muted">Önce PRE-TASE desenini kaydedin.</p>}{error&&<Notice warn>{error}</Notice>}
    </Card></div>
    <Card title="PRE-TASE PATTERN ↔ POST-OBSERVATION PATTERN">{before?<>
      {result&&signature!==currentSignature&&<Notice warn>Gözlem girdileri değişti; gösterilen karşılaştırmayı yenileyin.</Notice>}
      <div className="collocation-checks">{list(collocation.checks).map((c,i)=><span key={i} className={c.passed?'pass':'fail'}>{c.passed?'✓':'×'} {str(c.label)}</span>)}</div>
      <div className="before-after"><div><span>Kaydedilen saha öncesi</span><Status value={before.status}/><strong>{number(before.optimized?.totals.water_m3)}<small>m³ su</small></strong><span>{number(before.optimized?.totals.energy_kwh)} kWh</span></div><span>→</span><div><span>Gözlem sonrası</span>{after?<Status value={after.status}/>:<span>Henüz geçerli yeniden hesaplama yok</span>}<strong>{number(after?.optimized?.totals.water_m3)}<small>m³ su</small></strong><span>{number(after?.optimized?.totals.energy_kwh)} kWh</span></div></div>
      <p className="small">{str(comparison.reason)}</p><p className="small">{typeof result?.changed_pattern==='boolean'?result.changed_pattern?'Desen veya uygulanabilirlik değişti.':'Desen değişmedi; bu da geçerli bir sonuç.':''}</p>
      {Array.isArray(result?.change_summary)&&<ul className="small muted">{result.change_summary.map((v,i)=><li key={i}>{typeof v==='string'?v:JSON.stringify(v)}</li>)}</ul>}
      <div className="table-scroll"><table><thead><tr><th>Ürün</th><th>Önce ha / %</th><th>Sonra ha / %</th><th>Önce üretim kg</th><th>Sonra üretim kg</th></tr></thead><tbody>{before.optimized?.crops.map(c=>{const a=after?.optimized?.crops.find(a=>a.crop_id===c.crop_id);return <tr key={c.crop_id}><th>{c.name_tr}</th><td>{number(c.area_ha,2)} / {number(c.area_share_pct,1)}%</td><td>{a?`${number(a.area_ha,2)} / ${number(a.area_share_pct,1)}%`:'—'}</td><td>{number(c.production_kg)}</td><td>{number(a?.production_kg)}</td></tr>})}</tbody></table></div>
      <div className="table-scroll"><table><thead><tr><th>Ürün · yöntem · kaynak</th><th>Önce kapasite</th><th>Sonra kapasite</th><th>Önce → sonra su m³</th></tr></thead><tbody>{Array.from(new Set([...(before.optimized?.allocations||[]),...(after?.optimized?.allocations||[])].map(a=>`${a.crop_id}|${a.method}|${a.water_source}`))).map(key=>{const b=before.optimized?.allocations.find(a=>`${a.crop_id}|${a.method}|${a.water_source}`===key),a=after?.optimized?.allocations.find(a=>`${a.crop_id}|${a.method}|${a.water_source}`===key),row=b||a!;return <tr key={key}><th>{row.name_tr} · {methodName[row.method]} · {sourceName[row.water_source]}</th><td>{b?`${number(b.capacity_used,2)} ${b.capacity_unit}`:'—'}</td><td>{a?`${number(a.capacity_used,2)} ${a.capacity_unit}`:'—'}</td><td>{number(b?.water_m3)} → {number(a?.water_m3)}</td></tr>})}</tbody></table></div>
      <div className="two-columns"><div><h3>Önce bağlayıcı kısıtlar</h3><p className="small">{before.optimized?(before.constraints.filter(c=>c.binding).map(c=>c.label).join(' · ')||'Bildirilen bağlayıcı kısıt yok.'):'Uygulanabilir saha öncesi çözüm yok; aktif kısıt yorumu yapılmaz.'}</p></div><div><h3>Sonra bağlayıcı kısıtlar</h3><p className="small">{after?.optimized?(after.constraints.filter(c=>c.binding).map(c=>c.label).join(' · ')||'Bildirilen bağlayıcı kısıt yok.'):'Uygulanabilir saha sonrası çözüm yok; aktif kısıt yorumu yapılmaz.'}</p></div></div>
      {result&&<Download data={{snapshot,result}} filename="saha-oncesi-sonrasi-desen.json"/>}
    </>:<Empty>Önce kaydedilmiş bir PRE-TASE deseni oluşturun. Hesaplanmamış saha sonucu varmış gibi sayı gösterilmez.</Empty>}</Card>
    <Notice>Belirsizlik: saha öncesi kaynak girdisi MODEL / VARSAYIM; seçili gözlem yolu {kind==='SIMULATION_EXPLANATORY'?'SİMÜLASYON':'KAYITLI DIŞ GÖZLEM (eşleştirme gerekir)'}. Kayıtlı dış gözlem eşleşse bile güven puanı otomatik yükseltilmez, model kalibre edilmiş sayılmaz. Ürün, zemin, karasal su ve altyapı varsayımları aynen kalır.</Notice>
    <Notice>Deniz suyu gözlemi karasal yıllık tatlı su miktarını veya depolama kapasitesini ölçmez. Kaynak ile üretim sahasının fiziksel ilişkisi ayrıca doğrulanmalıdır. Fiziksel numune kimyası ve tuzluluk bugün optimizasyon girdisini güncellemez.</Notice>
  </>
}
